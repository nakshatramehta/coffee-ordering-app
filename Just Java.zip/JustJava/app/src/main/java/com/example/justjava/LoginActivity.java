package com.example.justjava;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity
{
EditText urname , urphoneno;
     Button clk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        urname = (EditText) findViewById(R.id.editText2);
        urphoneno = (EditText) findViewById(R.id.editText45);
        clk = (Button) findViewById(R.id.button111);

    }
    public void go1 (View view)
    {
        String stname  = urname.getText().toString();
        String stphoneno = urphoneno.getText().toString();

        if(stname.equals("User") && stphoneno.equals("321"))
        {
            Intent in = new Intent(LoginActivity.this,MainActivity.class);
            startActivity(in);
        }

        else if(stname.equals("") || stphoneno.equals(""))
        {
            Toast.makeText(getBaseContext(), "Enter Name and Phone" , Toast.LENGTH_SHORT ).show();

        }
        else
        {
            Toast.makeText(getBaseContext(), " Entered data is WRONG " , Toast.LENGTH_SHORT ).show();

        }

    }
}