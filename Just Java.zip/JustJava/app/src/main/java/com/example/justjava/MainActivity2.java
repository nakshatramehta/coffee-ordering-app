package com.example.justjava;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        submitOrder();

    }
    String print;
    public void submitOrder() {
        Intent rIntent = getIntent();
        int quantity = rIntent.getIntExtra("KEY_", 0);
        int quantity1 = rIntent.getIntExtra("KEY_1", 0);
        int quantity2 = rIntent.getIntExtra("KEY_2", 0);
        int quantity3 = rIntent.getIntExtra("KEY_3", 0);
        int quantity4 = rIntent.getIntExtra("KEY_4", 0);
        String num1 = rIntent.getStringExtra("PHONE_");
        String add1 = rIntent.getStringExtra("ADD_");
        String name1 = rIntent.getStringExtra("NAME_");



        int totalq  = quantity+quantity1+quantity2+quantity3+quantity4;
        int partq = quantity+quantity2+quantity3+quantity4;
        int totalp = price(partq , 60) + price(quantity1,50);


        print = summary(num1 , name1);
        print += "\n-------------------------------";
        if (quantity > 0) {
            print += "\n" + summarye(quantity);
        }
        if (quantity1 > 0) {
            print += "\n" + summarya(quantity1);
        }
        if(quantity2>0) {
            print += "\n" + summaryl(quantity2);
        }
        if(quantity3>0) {
            print += "\n" + summarym(quantity3);
        }
        if(quantity4>0) {
            print += "\n" + summaryc(quantity4);
        }
        print += "\n------------------------------";
        print += "\nAddress:- " + add1;
        print += "\n------------------------------";
        print += "\ncart total :- " + totalp;
        print += "\n------------------------------";
        displayMessage2(print);
        displayMessage("THANKS FOR PLACING ORDER");

    }

    private void displayMessage(String a) {
        TextView quantityTextView = (TextView) findViewById(R.id.message1_text_view);
        quantityTextView.setText("" +a);
    }
    private void displayMessage2(String message) {
        TextView price1TextView = (TextView) findViewById(R.id.price_text_view);
        price1TextView.setText(message);
    }
    private int price(int number ,int price1)
        {
        int price = number*price1;
        return price;
    }
public String summary(String num1 , String name1)
{
    String name = "Name :- " + name1;
    name += "\nphone number :- " + num1 ;
    name += "\n Order Summary:- " ;
    return name;
}
    public String summarye(int quantity)
    {
        String name;
        name = "Espresso:- " + quantity;
        name += "\nprice:- "  + price(quantity,60);
        return name;
    }
    public String summarya(int quantity)
    {
        String name;
        name = "Americano:- " + quantity;
        name += "\nprice:- "  + price(quantity,50);
        return name;
    }
    public String summaryl(int quantity)
    {
        String name;
        name = "Latte:- " + quantity;
        name += "\nprice:- "  + price(quantity,60);
        return name;
    }
    public String summarym(int quantity)
    {
        String name;
        name = "Mocha:- " + quantity;
        name += "\nprice:- "  + price(quantity,60);
        return name;
    }
    public String summaryc(int quantity)
    {
        String name;
        name = "Cappuccino:- " + quantity;
        name += "\nprice:- "  + price(quantity,60);
        return name;
    }
public void dial(View view) {

    String toNumber = "+91 6378688489"; // contains spaces.
    toNumber = toNumber.replace("+", "").replace(" ", "");

    Intent sendIntent = new Intent("android.intent.action.MAIN");
    sendIntent.putExtra("jid", toNumber + "@s.whatsapp.net");
    sendIntent.putExtra(Intent.EXTRA_TEXT,print);
    sendIntent.setAction(Intent.ACTION_SEND);
    sendIntent.setPackage("com.whatsapp");
    sendIntent.setType("text/plain");
    startActivity(sendIntent);



}

}