package com.example.justjava;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.provider.AlarmClock;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.*;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    int quantity = 0;
    public void increment(View view) {
        if (quantity == 9) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have more than 9 coffees", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity = quantity + 1;
        display(quantity);
    }
    public void decrement(View view) {
        if (quantity == 0) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have less than 0 coffee", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity = quantity - 1;
        display(quantity);
    }
    private void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view11);
        quantityTextView.setText("" + number);
    }

    int quantity1 = 0;
    public void increment1(View view) {
        if (quantity1 == 9) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have more than 9 coffees", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity1 = quantity1 + 1;
        display1(quantity1);
    }
    public void decrement1(View view) {
        if (quantity1 == 0) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have less than 0 coffee", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity1 = quantity1 - 1;
        display1(quantity1);
    }
    private void display1(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view12);
        quantityTextView.setText("" + number);
    }

    int quantity2 = 0;
    public void increment2(View view) {
        if (quantity2 == 9) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have more than 9 coffees", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity2 = quantity2 + 1;
        display2(quantity2);
    }
    public void decrement2(View view) {
        if (quantity2 == 0) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have less than 0 coffee", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity2 = quantity2 - 1;
        display(quantity2);
    }
    private void display2(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view13);

        quantityTextView.setText("" + number);
    }

    int quantity3 = 0;
    public void increment3(View view) {
        if (quantity3 == 9) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have more than 9 coffees", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity3 = quantity3 + 1;
        display3(quantity3);
    }
    public void decrement3(View view) {
        if (quantity3 == 0) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have less than 0 coffee", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity3 = quantity3 - 1;
        display3(quantity3);
    }
    private void display3(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view14);
        quantityTextView.setText("" + number);
    }

    int quantity4 = 0;
    public void increment4(View view) {
        if (quantity == 9) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have more than 9 coffees", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity4 = quantity4 + 1;
        display4(quantity4);
    }
    public void decrement4(View view) {
        if (quantity4 == 0) {
            // Show an error message as a toast
            Toast.makeText(this, "You cannot have less than 0 coffee", Toast.LENGTH_SHORT).show();
            // Exit this method early because there's nothing left to do
            return;
        }
        quantity4 = quantity4 - 1;
        display(quantity4);
    }
    private void display4(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view15);

        quantityTextView.setText("" + number);
    }


   public void show(View view)
   {
       EditText editText = (EditText) findViewById(R.id.editText1);
       EditText editText1 = (EditText) findViewById(R.id.editText2);
       EditText editText2 = (EditText) findViewById(R.id.editText3);
       Intent i = new Intent(MainActivity.this,MainActivity2.class);
       i.putExtra("KEY_" , quantity);
       i.putExtra("KEY_1" , quantity1);
       i.putExtra("KEY_2" , quantity2);
       i.putExtra("KEY_3" , quantity3);
       i.putExtra("KEY_4" , quantity4);
       i.putExtra("PHONE_",editText.getText().toString());
       i.putExtra("ADD_",editText1.getText().toString());
       i.putExtra("NAME_",editText2.getText().toString());

       try {
           startActivity(i);
       } catch (ActivityNotFoundException e) {
           // Define what your app should do if no activity can handle the intent.
       }

   }




}